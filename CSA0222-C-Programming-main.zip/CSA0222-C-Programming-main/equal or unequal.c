#include<stdio.h>
int main()
{
	int n1,n2;
	printf("enter the number:\n");
	scanf("%d",&n1);
	printf("enter the number:\n");
	scanf("%d",&n2);
	
	if(n1 == n2)
	printf("it is a equal number:\n");
	else
	printf("it is not a equal number:\n");
	return 0;
}