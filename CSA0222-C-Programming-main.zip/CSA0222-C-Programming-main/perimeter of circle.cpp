#include<stdio.h>
int main()
{
	int r;
	float pie=3.14,perimeter =0;
    scanf("%d",&r);
    perimeter =2*pie*r;
    printf("perimeter of circle:%f",perimeter);
    return 0;
		
}