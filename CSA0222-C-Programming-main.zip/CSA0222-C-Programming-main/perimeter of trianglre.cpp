#include<stdio.h>
int main()
{
	int i,a,b,c;
	float perimeter=0;
	scanf("%d%d%d",&a,&b,&c);
	perimeter = a+b+c;
    printf("perimeter of circle:%f",perimeter);
    return 0;
		
}