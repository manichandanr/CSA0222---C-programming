#include<stdio.h>
int main()
{
	int n;
	printf("enter the number:\n");
	scanf("%d",&n);
	if(n%2==0)
	printf("number is even number:\n");
	else
	printf("number is odd number:\n");
	return 0;
}