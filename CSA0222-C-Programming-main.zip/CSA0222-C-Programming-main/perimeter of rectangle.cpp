#include<stdio.h>
int main()
{
	int l,b;
	float perimeter=0;
	scanf("%d%d",&l,&b);
	perimeter = 2*(l+b);
    printf("perimeter of circle:%f",perimeter);
    return 0;
		
}