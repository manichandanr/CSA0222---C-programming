#include<stdio.h>
int main()
{
	float pie=3.14,area;
	int r;
	printf("enter the radius:");
	scanf("%d",&r);
	area =(pie*r*r);
	printf("area of circle is %f:",area);
	return 0;
}
	